var request = require('supertest');
var chai = require('chai');
chai.use(require('chai-json-schema'));
var assert = require('chai').assert
var fs = require('fs');
var yaml = require('js-yaml');
var crypto = require('crypto');

try {
  var config = yaml.safeLoad(fs.readFileSync('./test/integration/config/'+environment+'.yml', 'utf8'));
} catch (e) {
  console.log(e);
}

var endpoint = config.endpoint;

describe('JWT Acquisition Integration Test', function() {
  describe('Happy Path', function() {
    it('should acquire a JWT', function (done) {
    	
    	var request_time = new Date().getTime();
		var signature = crypto.createHash('sha1').update(config.secret_key+request_time).digest('hex');
    	var authorization_string = config.access_key+':'+request_time+':'+signature;
		console.log(authorization_string);
		var this_request = request(endpoint);
    	this_request.get('token/acquire/')
			.set('Content-Type', 'application/json')
			.set('Authorization', authorization_string)
			.expect(200)
			.expect('Content-Type', 'application/json')
			.expect('Access-Control-Allow-Origin','*')
			.expect('Access-Control-Allow-Methods', 'OPTIONS,POST')
			.expect('Access-Control-Allow-Headers','Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token')
			.end(function(err, response){
				assert.isObject(response.body);
				assert.property(response.body, "message");
				assert.equal(response.body.message, "Success");
				assert.property(response.body, "token");
				assert.isString(response.body.token);
				done();
			}, done);
		});
	});
	describe('Broken Path(s)', function() {
		it('should fail signature validation due to bad signature', function (done) {

			var request_time = new Date().getTime();
			var signature = crypto.createHash('sha1').update(config.secret_key+request_time).digest('hex')+'1';
			var authorization_string = config.access_key+':'+request_time+':'+signature;

			var this_request = request(endpoint);
			this_request.get('token/acquire/')
				.set('Content-Type', 'application/json')
				.set('Authorization', authorization_string)
				.expect(500)
				.expect('Content-Type', 'application/json')
				.end(function(err, response){
					assert.isObject(response.body);
					assert.property(response.body, "Message");
					assert.equal(response.body.Message, "User is not authorized to access this resource");
					done();
				}, done);
		});
		it('should fail signature validation due to bad access_key', function (done) {
		
			var request_time = new Date().getTime();
			var signature = crypto.createHash('sha1').update(config.secret_key+request_time).digest('hex');
			var authorization_string = 'abc123:'+request_time+':'+signature;

			var this_request = request(endpoint);
			this_request.get('token/acquire/')
				.set('Content-Type', 'application/json')
				.set('Authorization', authorization_string)
				.expect(500)
				.expect('Content-Type', 'application/json')
				.end(function(err, response){
					assert.isObject(response.body);
					assert.property(response.body, "Message");
					assert.equal(response.body.Message, "User is not authorized to access this resource");
					done();
				}, done);
		});
		
		it('should fail signature validation due to bad expired timestamp', function (done) {
	
			var request_time = 123;
			var signature = crypto.createHash('sha1').update(config.secret_key+request_time).digest('hex');
			var authorization_string = config.access_key+':'+request_time+':'+signature;
			
			var this_request = request(endpoint);
			this_request.get('token/acquire/')
				.set('Content-Type', 'application/json')
				.set('Authorization', authorization_string)
				.expect(500)
				.expect('Content-Type', 'application/json')
				.end(function(err, response){
					assert.isObject(response.body);
					assert.property(response.body, "Message");
					assert.equal(response.body.Message, "User is not authorized to access this resource");
					done();
				}, done);
		});
		
		it('should fail signature validation structure', function (done) {
	
			var request_time = new Date().getTime();
			var signature = crypto.createHash('sha1').update(config.secret_key+request_time).digest('hex');
			var authorization_string = config.access_key+''+request_time+':'+signature;
			
			var this_request = request(endpoint);
			this_request.get('token/acquire/')
				.set('Content-Type', 'application/json')
				.set('Authorization', authorization_string)
				.expect(500)
				.expect('Content-Type', 'application/json')
				.end(function(err, response){
					assert.isObject(response.body);
					assert.property(response.body, "Message");
					assert.equal(response.body.Message, "User is not authorized to access this resource");
					done();
				}, done);
		});
		
		it('should fail due to missing headers', function (done) {
	
			var request_time = new Date().getTime();
			var signature = crypto.createHash('sha1').update(config.secret_key+request_time).digest('hex');
			var authorization_string = config.access_key+''+request_time+':'+signature;
			
			var this_request = request(endpoint);
			this_request.get('token/acquire/')
				.expect(500)
				.expect('Content-Type', 'application/json')
				.end(function(err, response){
					assert.isObject(response.body);
					assert.property(response.body, "message");
					assert.equal(response.body.message, "Unauthorized");
					done();
				}, done);
		});
		
	});
});