'use strict';
//var { graphql, buildSchema } = require('graphql'); breaks Lambda
const graphql = require('graphql').graphql;
const buildSchema  = require('graphql').buildSchema;

var lr = require('../../lib/lambda-response.js');

module.exports.graph = (event, context, callback) => {
	
	var schema = buildSchema(`
	  type Query {
		hello: String
	  }
	`);

	var root = { hello: () => 'Hello world!' };

	graphql(schema, '{ hello }', root)
	.then((response) => {
	  return lr.issueResponse(200, response, callback);	
	})
	.catch((error) => {
    	return lr.issueError(error, 500, event, error, callback);
    });
    
}